
public class App {

	public static void main(String[] args) {
		
		Vetor vetor = new Vetor(10);
		Vetor vetor2 = new Vetor(5);
		System.out.println("Tamanho: " + vetor.tamanho());
		
		//adicionando um valor � string que for nula.
		vetor.adiciona("Salgueiro");
		System.out.println("Inserinto novo elemento...");
		System.out.println("Tamanho: " + vetor.tamanho());
		
		System.out.println("Testando o to string... \n" + vetor.toString());
	}

}
