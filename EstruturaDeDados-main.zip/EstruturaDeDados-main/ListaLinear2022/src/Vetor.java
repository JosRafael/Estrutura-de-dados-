import java.util.Arrays;

public class Vetor {
	//CRIANDO O ATRIBUTO ELEMENTOS - Elementos do vetor
	private String[] elementos;
	private int tamanho;
	
	//CRIANDO O CONSTRUTOR
	public Vetor(int capacidade) {
		this.elementos = new String[capacidade];
		this.tamanho = 0;
	}
	/*
	public void adiciona(String elemento) {
		for(int i = 0; i < this.elementos.length; i++) {
			if(this.elementos[i] == null) {
				this.elementos[i] = elemento;
				break;
			}
		}
	}
	
	*/ 
	public boolean adiciona(String elemento) {
		if(this.tamanho < this.elementos.length) {
			this.elementos[this.tamanho] = elemento;
			this.tamanho ++;
			return true;
			}
			return false;
	}
	public int tamanho() {
		return this.tamanho;
	}
	
	//Descobrindo quantos elementos possui o vetor (Percorrendo ele)
	public int tamanho2() {
		int contador = 0;
		for int i = 0; i < this.elementos.lenght; i++){
			if(this.elementos[i] != null) {
				contador++;
			}else {
				break;
			}
		}
		return contador;
	}
	@Override
	public String toString() {
		return "Vetor [elementos=" + Arrays.toString(elementos) + "]";
	}
}
